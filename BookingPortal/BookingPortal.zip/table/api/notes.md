API Endpoints(s) uri (url)
    - Retrieve Update Delete
    - Create & List & Search
    
 HTTP methods
    - GET, POST, PUT, PATCH, DELETE
    
Data Types & Validation
    - JSON -> Serializer
    - Validation -> Serializer